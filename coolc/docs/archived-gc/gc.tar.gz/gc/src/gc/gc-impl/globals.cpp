#include "gc/gc-interface/alloca.hpp"
#include "gc/gc-interface/gc.hpp"
#include "gc/gc-interface/mark.hpp"

bool LOGSWEEP = false;
bool LOGGING = false;
bool LOGMARK = false;
bool LOGALOC = false;
bool ZEROING = false;