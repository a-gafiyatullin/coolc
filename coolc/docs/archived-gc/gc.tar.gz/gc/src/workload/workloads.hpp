#include "linked-list-workloads.hpp"
#include "sanity-workloads.hpp"

// simple tests
void sanity_workload();
void linked_list_workload();